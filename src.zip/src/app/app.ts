import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Navbar } from './components/navbar/navbar';
import { Sidebar } from "./components/dashboard/sidebar/sidebar";
import { Dashboard } from "./components/dashboard/dashboard/dashboard";
import { AddProduct } from './components/dashboard/add-product/add-product';
import { AddCategory } from "./components/dashboard/category/category";


@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, Navbar, Sidebar],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('ShelfSense_UI');
}
