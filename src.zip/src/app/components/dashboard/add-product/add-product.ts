import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

interface Category {
  id: number;
  name: string;
}

@Component({
  selector: 'add-product',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule
  ],
  templateUrl: './add-product.html',
  styleUrls: ['./add-product.css']
})
export class AddProduct {
  productForm;
  categories: Category[] = [];

  constructor(private fb: FormBuilder, private http: HttpClient) {
    this.productForm = this.fb.group({
      stockKeepingUnit: ['', [Validators.required, Validators.maxLength(50)]],
      productName: ['', [Validators.required, Validators.maxLength(100)]],
      categoryId: ['', Validators.required],
      packageSize: ['', Validators.maxLength(50)],
      unit: ['', Validators.maxLength(20)]
    });

    this.loadCategories();
  }

  loadCategories() {
    this.http.get<Category[]>('/api/categories').subscribe({
      next: data => this.categories = data,
      error: err => console.error('Failed to load categories', err)
    });
  }

  onSubmit() {
    if (this.productForm.valid) {
      const data = this.productForm.value;
      this.http.post('/api/products', data).subscribe({
        next: res => {
          console.log('Product added', res);
          this.productForm.reset();
        },
        error: err => console.error('Error adding product', err)
      });
    }
  }

  get f() {
    return this.productForm.controls;
  }
}
