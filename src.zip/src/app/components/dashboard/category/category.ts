import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { HttpClientModule, HttpClient } from '@angular/common/http';

@Component({
  selector: 'add-category',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, HttpClientModule],
  templateUrl: './category.html',
  styleUrls: ['./category.css']
})
export class AddCategory {
  categoryForm;

  constructor(private fb: FormBuilder, private http: HttpClient) {
    this.categoryForm = this.fb.group({
      categoryName: ['', [Validators.required, Validators.maxLength(100)]],
      description: ['', Validators.maxLength(255)]
    });
  }

  onSubmit() {
    if (this.categoryForm.valid) {
      const data = this.categoryForm.value;
      this.http.post('/api/categories', data).subscribe({
        next: res => {
          console.log('Category created', res);
          this.categoryForm.reset();
        },
        error: err => console.error('Error creating category', err)
      });
    }
  }

  get f() {
    return this.categoryForm.controls;
  }
}
