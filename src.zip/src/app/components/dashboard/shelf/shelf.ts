import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { HttpClientModule, HttpClient } from '@angular/common/http';

@Component({
  selector: 'add-shelf',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, HttpClientModule],
  templateUrl: './shelf.html',
  styleUrls: ['./shelf.css']
})
export class AddShelf {
  shelfForm;
  categories: { id: number; name: string }[] = [];

  constructor(private fb: FormBuilder, private http: HttpClient) {
    this.shelfForm = this.fb.group({
      shelfCode: ['', [Validators.required, Validators.maxLength(50)]],
      storeId: [null, Validators.required],
      categoryId: [null, Validators.required],
      locationDescription: ['', Validators.maxLength(100)],
      capacity: [null, [Validators.required, Validators.min(1)]]
    });

    this.loadCategories();
  }

  loadCategories() {
    this.http.get<any[]>('/api/categories').subscribe(data => this.categories = data);
  }

  onSubmit() {
    if (this.shelfForm.valid) {
      this.http.post('/api/shelves', this.shelfForm.value).subscribe({
        next: res => {
          console.log('Shelf created', res);
          this.shelfForm.reset();
        },
        error: err => console.error('Error creating shelf', err)
      });
    }
  }

  get f() {
    return this.shelfForm.controls;
  }
}
