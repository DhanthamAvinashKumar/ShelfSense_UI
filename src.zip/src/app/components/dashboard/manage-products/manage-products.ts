import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { HttpClientModule, HttpClient } from '@angular/common/http';

@Component({
  selector: 'manage-product',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, HttpClientModule],
  templateUrl: './manage-products.html',
  styleUrls: ['./manage-products.css']
})
export class ManageProducts {
  mappingForm;
  products: { id: number; name: string }[] = [];
  shelves: { id: number; code: string }[] = [];

  constructor(private fb: FormBuilder, private http: HttpClient) {
    this.mappingForm = this.fb.group({
      productId: ['', Validators.required],
      shelfId: ['', Validators.required],
      quantity: [null, [Validators.required, Validators.min(0)]],
      lastRestockedAt: ['']
    });

    this.loadDropdowns();
  }

  loadDropdowns() {
    this.http.get<any[]>('/api/products').subscribe(data => this.products = data);
    this.http.get<any[]>('/api/shelves').subscribe(data => this.shelves = data);
  }

  onSubmit() {
    if (this.mappingForm.valid) {
      this.http.post('/api/product-shelves', this.mappingForm.value).subscribe({
        next: res => {
          console.log('Product mapped to shelf', res);
          this.mappingForm.reset();
        },
        error: err => console.error('Error mapping product', err)
      });
    }
  }

  get f() {
    return this.mappingForm.controls;
  }
}
