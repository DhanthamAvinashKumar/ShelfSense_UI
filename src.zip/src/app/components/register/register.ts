import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, HttpClientModule, RouterModule],
  templateUrl: './register.html',
  styleUrls: ['./register.css']
})
export class Register {
  registerForm;

  constructor(private fb: FormBuilder, private http: HttpClient) {
    this.registerForm = this.fb.group({
      storeId: [null, [Validators.required]],
      name: ['', [Validators.required, Validators.maxLength(100)]],
      role: ['staff', [Validators.required]],
      email: ['', [Validators.required, Validators.email]],
      passwordHash: ['', [Validators.required, Validators.minLength(6)]]
    });
  }

  onSubmit() {
  if (this.registerForm.valid) {
    const formData = this.registerForm.value;
    this.http.post('/api/staff', formData).subscribe({
      next: res => {
        console.log('Staff created successfully', res);
        this.registerForm.reset(); // ✅ Clears all fields
      },
      error: err => console.error('Error creating staff', err)
    });
  }
}


  get f() {
    return this.registerForm.controls;
  }
}
