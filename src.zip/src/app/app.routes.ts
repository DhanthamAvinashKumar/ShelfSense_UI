// import { Routes } from '@angular/router';
// import { Register } from './components/register/register';
// import { Login } from './components/login/login';

// export const routes: Routes = [
//   { path: 'register', component: Register },
//   { path: 'login', component: Login },
//   { path: '', redirectTo: 'register', pathMatch: 'full' }
// ];

import { Routes } from '@angular/router';
import { Register } from './components/register/register';
import { Login } from './components/login/login';
import { Dashboard } from './components/dashboard/dashboard/dashboard';
import { AddProduct } from './components/dashboard/add-product/add-product';
import { AddCategory } from './components/dashboard/category/category';
import { AddShelf } from './components/dashboard/shelf/shelf';
import { ManageProducts } from './components/dashboard/manage-products/manage-products';

export const routes: Routes = [
  { path: '', redirectTo: 'register', pathMatch: 'full' },
  { path: 'register', component: Register },
  { path: 'login', component: Login },
  { path: 'dashboard', component: Dashboard },
  { path: 'add-product', component: AddProduct },
  { path: 'add-category', component: AddCategory },
  { path: 'add-shelf',component:AddShelf},
  { path: 'manage-products',component:ManageProducts}
];
